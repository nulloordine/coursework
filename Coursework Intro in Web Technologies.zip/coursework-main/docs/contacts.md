# Контакты

Если у вас есть вопросы по курсовой, предложения или обратная связь — напишите в удобном канале ниже.

<div class="grid cards" markdown="1">

-   :simple-telegram: **Telegram**

    Самый быстрый способ связаться.

    [:simple-telegram: Написать](https://t.me/julienko){ .md-button .md-button--primary }

-   :simple-github: **GitHub**

    Вопросы по коду и задачам — через Issues.

    [:simple-github: Открыть профиль](https://github.com/juliadv8){ .md-button }

</div>
