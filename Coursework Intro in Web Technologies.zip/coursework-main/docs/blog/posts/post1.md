# Пост 1

Текст для поста 
![Печалька](https://github.com/juliadv8/coursework/blob/main/docs/images/post1.png)
